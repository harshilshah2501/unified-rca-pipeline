# Edge Delta — supported scenarios (what they actually publish)

**Hub:** [`ed-ai-team-hub.html`](./ed-ai-team-hub.html) · **HTML:** [`ed-supported-scenarios.html`](./ed-supported-scenarios.html) · **Lab:** [`ed-lab-setup.html`](./ed-lab-setup.html)  
**Date:** 2026-08-14  
**Honesty:** Public framing (vendor docs) + Observed (UI) tenant + Observed (MCP) this session.

## Headline

Edge Delta does **not** publish a Davis-style Detect-class list (ERROR · SLOWDOWN · AVAILABILITY · …). There is no integer “N RCA scenarios” in that sense.

They publish **three different catalogs**. Do not add them into one number.

### How the three catalogs differ

One pipeline, three jobs. They stack; they are not three names for the same list.

```text
  Packs shape the stream     →     Monitors notice     →     Use cases investigate
  (hygiene at the edge)            (how an alert fires)      (who looks, with which tools)
```

| | **Packs Library (43)** | **Monitor types (8)** | **AI Team use cases (10)** |
|--|------------------------|------------------------|----------------------------|
| **Job** | Shape data | Fire a signal | Run an investigation |
| **Question** | How do I parse / mask / route *this source*? | *How* do I decide something is wrong? | *Who* looks, with which connectors? |
| **Lives** | Inside a Telemetry Pipeline (edge) | Backend Monitors (or Pipeline Triggers at the edge) | AI Team (Overview / Issues / channels) |
| **You install** | A reusable node-group (e.g. Nginx Pack) | A monitor of a type (e.g. Metric Threshold) | A recipe (connectors + teammates + maybe a monitor) |
| **Fires an alert?** | No | Yes (when configured) | Uses alerts / webhooks / chat as *input* |
| **Closest DT/DD analog** | Not a Detect class. Closer to a reusable pipeline snippet | Datadog *monitor types* (Metric / Anomaly / Synthetics) — **not** Davis ERROR/SLOWDOWN | A playbook, not a Problem category |
| **This tenant** | None in UI | 5 monitors, 3 types | Only GitHub + ED MCP — use cases 1 and 9 can fire |

**Packs Library:** pre-built pipeline segments from Edge Delta’s Knowledge tab. Drop one onto a pipeline to grok Nginx, mask CloudTrail, or format logs for Datadog. Hygiene. Shift processing left.

**Monitor types:** the *evaluation method* for an alert — fixed threshold, rate-of-change, rolling σ, log volume, pattern spike, GitHub event count, composite, HTTP probe. Same layer as Detect. Not fault semantics.

**AI Team use cases:** end-to-end investigation setups (“when a pattern spikes, OnCall hands SRE + Code Analyzer the MCP”). They *consume* monitors and *sit on* packed pipelines. They are not extra monitor types.

Plus: **5** out-of-the-box teammates · **2** default monitors on a new org.

Sources: [AI Team Use Cases](https://docs.edgedelta.com/ai-team-use-cases/) · [Getting Started with AI Team](https://docs.edgedelta.com/getting-started-ai-team/) · [Monitors](https://docs.edgedelta.com/monitors/) · [Packs](https://docs.edgedelta.com/packs/).

---

## 1. Ten AI Team investigation scenarios (Public framing)

Each use case is an Input → Process → Output recipe: webhooks / user requests / monitor alerts in; pipelines + monitors + teammates + human approval in the middle; connector actions / recommendations / comms out.

| # | Use case | What it is for | Typical connectors |
|---|----------|----------------|--------------------|
| 1 | **Anomaly-triggered investigation** | Pattern-anomaly spike → OnCall delegates to SRE + Code Analyzer | Edge Delta MCP, GitHub, Pattern Anomaly Monitor |
| 2 | **Security-related degradation** | Perf/infra change that might be compromise — Security Engineer joins SRE | Edge Delta MCP, AWS, GitHub |
| 3 | **Cross-platform telemetry investigation** | Correlate Edge Delta with another lake (e.g. Elasticsearch MCP) | Edge Delta MCP, Elastic MCP |
| 4 | **Database performance investigation** | Frontend → backend → Postgres cascade (slow queries / pool) | Edge Delta MCP, GitHub, streaming sources |
| 5 | **CI/CD pipeline failure** | Code change vs flake vs environment | CircleCI, GitHub, Edge Delta MCP |
| 6 | **Ingest failure investigation** | Kafka / ingest API / storage cascade | Edge Delta MCP, GitHub, Pattern Anomaly Monitor |
| 7 | **PagerDuty incident response automation** | Webhook in; confidence-gated actions; human approval | PagerDuty, Edge Delta MCP, GitHub |
| 8 | **Kubernetes troubleshooting** | Pod logs, cluster events, HPA / scheduling | Edge Delta MCP, GitHub, Kubernetes source |
| 9 | **GitHub development workflow automation** | PR review, release readiness, Actions failures (`@edge-delta`) | GitHub, Edge Delta MCP |
| 10 | **Data locality for AI-driven investigations** | Why to route telemetry *through* Edge Delta so MCP is native | Edge Delta MCP, streaming, PagerDuty optional |

**This tenant (Observed UI + MCP):** GitHub + Edge Delta MCP + Edge Delta Documentation. Use case **9 is executing** (daily GitHub risk report — [`edgedelta-uc9-github-2026-08-17.md`](./edgedelta-uc9-github-2026-08-17.md)). Use case 1 still needs Node/Gateway. Issues **0**.

---

## 2. Eight monitor types (Detect mechanisms — not fault classes)

[Getting Started](https://docs.edgedelta.com/getting-started-ai-team/) says you can create **seven** types: Metric Threshold · Metric Change · Log Threshold · Pattern Anomaly · Composite · Synthetic · Event.

The [Monitors](https://docs.edgedelta.com/monitors/) section also documents **Metric Anomaly** (rolling baseline / σ band) as its own type, and that index omits Event.

**Union = 8 types.** Do not treat “seven” as a closed enum.

| Type | Job | Opens a Davis-like category? |
|------|-----|------------------------------|
| **Metric Threshold** | Fixed numeric threshold on a metric | No |
| **Metric Change** | Rate-of-change vs history | No |
| **Metric Anomaly** | Rolling mean ± Nσ | No |
| **Log Threshold** | Log volume / severity counts | No |
| **Pattern Anomaly** | Unusual log-pattern spike | No — not Watchdog, not Davis Event |
| **Event** (Observed UI: Event Threshold) | Event-source thresholds (e.g. GitHub) | No |
| **Composite** | Combine other monitor conditions | No |
| **Synthetic** | Periodic HTTP health check | No |

Two complementary Detect *locations* (not extra types): **Pipeline Triggers** (edge, one pipeline) ∥ **Monitors** (backend, cross-pipeline). [Pipeline Triggers](https://docs.edgedelta.com/pipeline-triggers/).

**Default monitors on a new org (Public framing):**

| Monitor | Type | Job |
|---------|------|-----|
| Default Service Anomaly | Pattern Anomaly | Pattern spike grouped by service |
| Default Pipeline Liveness | Metric Threshold | Agent heartbeat gone |

**This tenant Observed (UI):** 5 monitors — Event Threshold **3** (No Data) · Pattern Anomaly **1** (No Data) · Metric Threshold **1** (Pipeline Liveness **OK**). Alert **0**.

---

## 3. Forty-three Packs Library recipes (hygiene, not Detect)

[Packs overview](https://docs.edgedelta.com/packs/): “Showing **43** available packs.” A pack is a reusable pipeline segment. Two kinds: org-authored vs Edge Delta library (Knowledge tab).

| Kind | Count | Examples |
|------|------:|----------|
| **Source** | **36** | Nginx, Istio, AWS CloudTrail / VPC / Lambda / CloudWatch, Okta, Palo Alto, Windows Event, Syslog, MySQL Error / Slow Query, … |
| **Processing** | **3** | Dynamic Flow Control, Dynamic Sample Control, Large Message |
| **Destination** | **3** | Datadog K8s, New Relic Entities, Splunk Rosetta Stone |
| **Example** | **1** | Lookup Examples |
| **Total** | **43** | |

These are **shift-left** recipes (parse / mask / route for a source or dest). They are not ERROR/SLOWDOWN tabs.

**This tenant:** no Packs Observed in the UI. MCP listed one pipeline (below) with GitHub connector filters, not a library pack.

---

## 4. Five teammates (not scenarios)

Public framing + Observed UI cards: **OnCall AI** (orchestrator) · **SRE** · **Code Analyzer / Software Engineer** · **Security Engineer** · **Work Tracker**.

OnCall was not a card on this tenant; docs still name it as the router.

---

## 5. MCP this session (Observed)

Org `6da947fe-77af-421e-8a9c-dda8ead0b393`.

| Object | Result |
|--------|--------|
| Pipelines | **1:** `AI-Connector-Telemetry-Pipeline` (`dc098347-…`) · `fleet_type=IngestionPipeline` · `purpose=edgedelta-ai` · GitHub HTTP ingestion → `ed_ai_event_output` + Edge Delta dest |
| `event.type` facet | **0** values (empty event store) |
| Logs / traces / metrics explorers | Empty (UI snapshot) |

That hidden ingestion pipeline explains Pipeline Liveness **OK** without a Pipelines nav item: control-plane / AI-connector fleet, not application MELT.

---

## 6. E1–E11 on three actors (teaching map — Inferred on Public framing)

**Actors the user named:** Node Pipeline · Gateway Pipeline · Standing AI Team.

**Honesty:** this is a **teaching distribution**, not an Edge Delta SKU map and not Observed lab. Grounded in [Edge Delta Architecture](https://docs.edgedelta.com/edge-delta-architecture/) (Public framing) + our HLD I/O. This tenant has **no** Node/Gateway app fleet — only `AI-Connector-Telemetry-Pipeline`.

**Two pieces that are not those three actors (do not hide them):**

| Extra | Why it exists | HLD stages |
|-------|-----------------|------------|
| **Coordinator Pipeline** | Cluster control plane: discovery, agent grouping, live capture | Mostly **E5** |
| **Platform index + Monitors** | Lake + org-wide Detect after egress | **E4** persist · **E6** org door |

Legend: **P** primary writer/owner · **A** assist · **R** read-only evidence · **—** not this actor.

### Phase rollup

| Phase | Who owns the work | One line |
|-------|-------------------|----------|
| **P1 Fabric (E1–E5)** | **Node ∥ Gateway** (shift left). Team only reads. | Shape and write the estate before an alert. |
| **P2 Triage (E6–E8)** | **E6 split**; **E7–E8 Team** | Edge can fire; Issue/working-set is the Team. |
| **P3 Diagnose (E9–E11)** | **Standing AI Team**. Pipelines stay the evidence factory. | Leaf, corroboration, verdict card. |

```text
  Node (per-node DaemonSet)     Gateway (cluster Deployment)
       \                         /
        \  processed telemetry  /
         \                     /
          Platform index  +  Monitors (org Detect)
                           |
                    Standing AI Team
                 (E7–E11 + E6 consume)
```

### Stage distribution

| Stage | Node Pipeline | Gateway Pipeline | Standing AI Team |
|-------|---------------|------------------|------------------|
| **E1 Collect** | **P** — node-local: container logs, host metrics, K8s events, eBPF traces | **P** — pushed OTLP / 3rd-party agents / anything that needs aggregation | **—** (GitHub→`AI-Connector` ingest is a Cloud/Ingestion exception, not Node/Gateway) |
| **E2 Identity** | **P** — OTel / OCSF + pipeline tags / `edCustomTags` at the agent | **A** — cluster enrich, dest-compat packs | **—** |
| **E3 Topology** | **P** — eBPF service map at the node (**Public framing**) | **A** — service-level metrics, tail sampling (needs full trace context) | **R** — MCP / Service Map UI |
| **E4 Stores** | **A** — route out; not the lake | **A** — route out; not the lake | **R** — MCP query. Persist is **Platform**, not an actor here |
| **E5 Maintain** | **A** — agent heartbeat, Packs on node config | **A** — gateway fleet health | **R** — Pipeline Liveness *watches* them. **Coordinator** owns control plane |
| **E6 Detect** | **P (edge door)** — Pipeline Triggers, pattern / extract-metric on this pipeline | **P (cluster door)** — service-level / cross-node Detect inputs | **P (org door)** — Platform Monitors notify channels. Team does **not** compute the threshold |
| **E7 Curate** | **—** | **—** | **P** — Issue match (join or create) |
| **E8 Scope** | **R** — node-local evidence | **R** — wider cluster picture | **P** — lock working set (services / envs / window) |
| **E9 Localize** | **R** | **R** | **P** — SRE teammate names the leaf |
| **E10 Identify** | **R** | **R** | **P** — MCP corroboration + citations |
| **E11 Package** | **—** | **—** | **P** — Issue card + Overview + human approval for actions |

**E6 is the only stage with three real doors.** Edge trigger (Node or Gateway) vs org Monitor (feeds the Team). Same Detect *layer*, different *where*.

**P3 does not move onto the Team and leave pipelines idle.** Node/Gateway keep writing; Diagnose **reads** that estate. If Fabric is empty, use case 1 has nothing to investigate (this tenant).

### Implication for use case 1 (anomaly-triggered investigation)

Need, in order: **Node or Gateway** emitting patterns → **Pattern Anomaly monitor** (org door) → **OnCall → SRE + Code Analyzer**. Packs optional (cleaner patterns). This tenant: no app Node/Gateway, Pattern Anomaly **No Data**, Issues **0**.

---

## Do not equate

- 10 use cases ≠ 6 Davis categories ≠ 11 Datadog Host+APM pack templates
- 8 monitor types ≠ `event.category`
- 43 packs ≠ Detect classes
- Pattern Anomaly ≠ Watchdog story ≠ Davis Event
- Issue ≠ Problem ≠ Bits ≠ Incident
