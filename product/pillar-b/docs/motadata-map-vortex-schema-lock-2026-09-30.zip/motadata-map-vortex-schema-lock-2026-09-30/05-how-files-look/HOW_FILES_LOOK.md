# How Arrow and Vortex files look for this schema

Demo estate: **2 nodes** (`checkout-api` service, `linux-server-app-01` host) + **1 edge** (`RUNS_ON`), published as Motadata `vortex_s3.v1` flat lock (2026-09-30).

Generated with `map_vortex_demo --tenant-root … --version lab-1 --verify-load`.

## Dest tree (what lands on S3 / lab path)

```text
map/<tenant>/                          ← folder in this pack: dest-tree/
  latest.json                          ← { "version": "lab-1" }
  snapshots/lab-1/
    manifest.json                      ← lists node_parts / edge_parts + counts
    nodes/part-00000.arrow             ← optional Arrow IPC twin (debug)
    nodes/part-00000.vortex            ← Motadata cold SoT
    edges/part-00000.arrow
    edges/part-00000.vortex
```

| File | Approx size (this demo) | Role |
|------|-------------------------|------|
| `nodes/part-00000.vortex` | ~9.6 KB | Cold nodes |
| `edges/part-00000.vortex` | ~7.4 KB | Cold edges |
| `nodes/part-00000.arrow` | ~4.3 KB | Same columns as Vortex; IPC for tools / debug |
| `edges/part-00000.arrow` | ~3.0 KB | Same for edges |
| `manifest.json` / `latest.json` | small JSON | ObserveOps index — **not** inside Vortex postscript |

Open the binaries under `dest-tree/`. Open the human-readable dumps under `text-dumps/`.

---

## Arrow IPC — schema + rows

Full dump: [`text-dumps/arrow_ipc_dump.txt`](./text-dumps/arrow_ipc_dump.txt)

### `map_nodes` schema (from the `.arrow` file)

```text
entity_id: string not null
type: string not null
name: string not null
env: string
region: string
owner: string
namespace: string
last_seen: uint64 not null
valid_from: uint64
valid_to: uint64
version: uint32 not null
-- schema metadata --
observeops.attr_catalog: 'attr_catalog.v1'
observeops.schema_version: 'graph_node.v1'
observeops.table: 'map_nodes'
```

### `map_nodes` rows (demo)

| entity_id | type | env | last_seen | valid_from | version |
|-----------|------|-----|-----------|------------|---------|
| checkout-api | service | rca-lab | 1787196600000 | 1787184000000 | 1 |
| linux-server-app-01 | host | rca-lab | 1787196600000 | 1787184000000 | 1 |

(`region` / `owner` / `namespace` / `valid_to` are null in this demo.)

### `map_edges` schema

```text
edge_id: uint64 not null
source_id: string not null
target_id: string not null
edge_type: string not null
valid_from: uint64
valid_to: uint64
evidence_event_id: uint64 not null
-- schema metadata --
observeops.schema_version: 'graph_edge.v1'
observeops.table: 'map_edges'
```

### `map_edges` row (demo)

| edge_id | source_id | target_id | edge_type | valid_from | evidence_event_id |
|---------|-----------|-----------|-----------|------------|-------------------|
| 7146828800000001 | checkout-api | linux-server-app-01 | RUNS_ON | 1787184000000 | 7146828800000002 |

---

## Vortex — `vx tree layout` (physical dtype tree)

Full dumps:

- [`text-dumps/nodes.vortex.tree-layout.txt`](./text-dumps/nodes.vortex.tree-layout.txt)
- [`text-dumps/edges.vortex.tree-layout.txt`](./text-dumps/edges.vortex.tree-layout.txt)
- [`text-dumps/nodes.vortex.inspect.txt`](./text-dumps/nodes.vortex.inspect.txt)
- [`text-dumps/edges.vortex.inspect.txt`](./text-dumps/edges.vortex.inspect.txt)

### Nodes root dtype (verbatim from demo file)

```text
vortex.struct, dtype: {
  entity_id=utf8, type=utf8, name=utf8,
  env=utf8?, region=utf8?, owner=utf8?, namespace=utf8?,
  last_seen=u64, valid_from=u64?, valid_to=u64?, version=u32
}, children: 11
```

Each field is a `vortex.zoned` child (data segment + zone stats).  
**Note:** `last_seen` / validity are **`u64`**, not utf8. There is **no** `metadata` utf8 bag.

### Edges root dtype

```text
vortex.struct, dtype: {
  edge_id=u64, source_id=utf8, target_id=utf8, edge_type=utf8,
  valid_from=u64?, valid_to=u64?, evidence_event_id=u64
}, children: 7
```

### Reproduce layout locally

```bash
vx tree layout dest-tree/snapshots/lab-1/nodes/part-00000.vortex
vx tree layout dest-tree/snapshots/lab-1/edges/part-00000.vortex
vx inspect dest-tree/snapshots/lab-1/nodes/part-00000.vortex
```

Arrow IPC (optional):

```bash
# with pyarrow
python -c "import pyarrow.ipc as ipc; print(ipc.open_file('dest-tree/snapshots/lab-1/nodes/part-00000.arrow').read_all().schema)"
```

---

## What this proves for Vortex review

1. Wire JSON integers (epoch ms) become Arrow/Vortex **UInt64** columns with zone min/max.
2. Promoted tags are real nullable Utf8 children (`env` has values; `region`/`owner`/`namespace` null here still occupy typed columns).
3. Cold Motadata object is **`.vortex`**; `.arrow` is a same-schema twin for tooling.
4. `manifest.json` / `latest.json` are ObserveOps footers beside the parts.
