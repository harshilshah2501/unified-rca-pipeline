# Motadata map Vortex schema lock — share pack (2026-09-30)

Handoff for the **Vortex / SpiralDB** team: Motadata present-topology `map/` on **`vortex_s3.v1`**.

**Start here if you only open one folder:** [`05-how-files-look/`](./05-how-files-look/) — real `.arrow` / `.vortex` parts from the locked schema, plus `vx tree layout` dumps and Arrow IPC schema+row dumps. Guide: [`05-how-files-look/HOW_FILES_LOOK.md`](./05-how-files-look/HOW_FILES_LOOK.md).

---

## Suggested reading order

| Order | Folder | Purpose |
|-------|--------|---------|
| **1** | `05-how-files-look/` | **What the files look like** — Dest tree binaries + text dumps of Arrow schema/rows and Vortex layout (`u64` clocks, `attr_catalog.v1` tags, no metadata bag). |
| **2** | `01-columnar-lock/` | Normative column list / design locks (`MAP_VORTEX_COLUMNAR_SCHEMA.md`). |
| **3** | `02-json-schemas/` | Wire JSON Schema SoT (`graph_node.v1` / `graph_edge.v1`) — same flat shape as Vortex. |
| **4** | `03-samples/` | Example JSON rows (epoch-ms integers). |
| **5** | `04-arrow-vortex-rust/` | How we build Arrow + call Vortex write (`schema.rs`, `tables.rs`, `write.rs`). |

---

## Locked shape (one screen)

- Tables: `map_nodes`, `map_edges` only.
- Clocks / snowflakes: **UInt64** epoch **ms**.
- Node tags: closed **`attr_catalog.v1`** — `env`, `region`, `owner`, `namespace`.
- **No** nested `metadata` JSON column on cold.
- Tenant on Dest path, not a column.
- Motadata cold SoT = **`.vortex`**; `.arrow` IPC twins are debug/tooling.
- `manifest.json` + `latest.json` = ObserveOps index beside parts.

Demo in `05-how-files-look/dest-tree/`: **2 nodes, 1 edge**, `load_map` verified.

PoC crate pins (`04-arrow-vortex-rust/Cargo.toml`): `arrow` 59.3.0 · `vortex` 0.86.1.

---

## Pack tree

```text
README.md
01-columnar-lock/MAP_VORTEX_COLUMNAR_SCHEMA.md
02-json-schemas/graph_{node,edge}_v1.schema.json
03-samples/graph_{node,edge}.example.json
04-arrow-vortex-rust/{Cargo.toml,schema.rs,tables.rs,types.rs,write.rs}
05-how-files-look/
  HOW_FILES_LOOK.md
  dest-tree/          ← latest + manifest + part-00000.{arrow,vortex}
  text-dumps/         ← Arrow IPC dump + vx tree layout + vx inspect
```
