# Repo hygiene — what to edit where (current stage)

**Stage:** Motadata Pillar A+B freeze + ObserveOps E1–E5 always-on fabric (2026-08-27).  
**Reading path:** [`NAVIGATION.md`](./NAVIGATION.md).

## Canonical paths (edit these)

| Artifact | Edit here only |
|----------|----------------|
| Graph + sketch sit-down brief | [`pillar-ab-implementation/contracts/GRAPH_CONTRACT_V1_DISCUSSION_BRIEF.md`](../pillar-ab-implementation/contracts/GRAPH_CONTRACT_V1_DISCUSSION_BRIEF.md) (`docs/` is a symlink) |
| Fabric Q&A (E1–E5) | [`pillar-ab-implementation/contracts/GRAPH_QNA.md`](../pillar-ab-implementation/contracts/GRAPH_QNA.md) (`docs/GRAPH_QNA.md` is a symlink) |
| Node/edge samples | [`pillar-ab-implementation/contracts/GRAPH_NODE_EDGE_SAMPLES.md`](../pillar-ab-implementation/contracts/GRAPH_NODE_EDGE_SAMPLES.md) |
| JSON schemas | [`pillar-ab-implementation/contracts/`](../pillar-ab-implementation/contracts/) (mirrored into packages for tests) |
| Motadata kickoff scope | [`pillar-ab-implementation/scope/`](../pillar-ab-implementation/scope/) |
| Pillar A deep dive + fabric HTML | [`docs/`](./) (`PILLAR_A_PERCENTILES_DEEP_DIVE.md`, `e1-e5-*.html`, `map-history-*.html`, `vortex-s3-interaction.html`) |
| Owner package **code** | [`pillar-a/poc/`](../pillar-ab-implementation/pillar-a/poc/), [`pillar-b/poc/`](../pillar-ab-implementation/pillar-b/poc/), [`integration/`](../pillar-ab-implementation/integration/) |

Owner-package `docs/` folders are **symlinks** into the paths above — do not replace them with real copies.

## Do not edit for the live hub

| Path | Why |
|------|-----|
| [`_archive/`](../_archive/) | Parked snapshots — not `:8765` |
| [`benchmarking/dashboard/`](../benchmarking/dashboard/) | Host + symlinks only — never a second article tree |
| [`pillar-ab-implementation/poc/`](../pillar-ab-implementation/poc/) | Legacy combined PoC (archived or frozen) — use `pillar-a` / `pillar-b` |
| Handoff `.zip` files | Rebuild after contract/doc changes; do not hand-edit insides |

## Handoff zip policy

1. Build from `pillar-a/` (or `pillar-b/`) **after** docs are symlink-clean.  
2. Exclude `.venv/`, `__pycache__/`, `*.pyc`, local `poc/out/`.  
3. Name with date: `pillar-a-handoff-YYYY-MM-DD.zip`.  
4. Zip should resolve teaching docs via package `docs/` symlinks (or include the linked files when archiving — `zip -y` keeps symlinks; prefer including content with `zip -r` following links for teammate machines without the monorepo).

**Preferred teammate zip:** follow symlinks so the archive is self-contained (`zip -r --symlinks` off / use `rsync -L` into a staging dir, then zip).

## Local bulk (not day-to-day Motadata edit)

| Path | Notes |
|------|--------|
| `datasets/ingest_samples/` | Large dumps (~GBs); gitignored patterns already |
| `federated-pipeline/Nezha/` | Vendor tree; bakeoff comparator only |
| `*/.venv/` | Local; never commit or ship in handoff |

## Hub publish rule

Edit `docs/` or `pillar-ab-implementation/` only. Dashboard mounts them. See root [`README.md`](../README.md).
